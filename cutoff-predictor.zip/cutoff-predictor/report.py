"""
AI-Based Career Counseling Report Generator
─────────────────────────────────────────────
Install:  pip install flask flask-cors google-generativeai reportlab
Run:      python career_counseling.py
Visit:    http://localhost:5000
"""

from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import google.generativeai as genai
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
)
from reportlab.lib.units import inch, mm
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
import io, json, re, threading, time, datetime

app = Flask(__name__)
CORS(app)

# ── Gemini ─────────────────────────────────────────────────────────────────
GEMINI_API_KEY = "AIzaSyBZXOLCxWOyaNFrjpSUNNYv5e2rZCh2sdg"          # <- paste your Gemini API key here
genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel("gemini-2.5-flash")

# ── AI Prompt ──────────────────────────────────────────────────────────────
PROMPT_TEMPLATE = """You are a career counselor. Analyze the student questionnaire and return ONLY a valid JSON object — no markdown, no explanation.

Student Responses:
{responses}

Return exactly this JSON structure:

{{
  "student_name": "string",
  "age_group": "string (e.g. 16-18 / 18-22 / 22+)",
  "personality_type": "string (e.g. Analytical Thinker)",
  "mbti_code": "string (e.g. INTJ)",
  "overall_fit_score": 87,

  "trait_scores": {{
    "Analytical":    82,
    "Creative":      65,
    "Leadership":    70,
    "Communication": 75,
    "Technical":     80,
    "Empathy":       60
  }},

  "top_strengths": [
    {{"name": "Strength 1", "score": 90}},
    {{"name": "Strength 2", "score": 85}},
    {{"name": "Strength 3", "score": 78}},
    {{"name": "Strength 4", "score": 72}},
    {{"name": "Strength 5", "score": 68}}
  ],

  "improvement_areas": [
    {{"name": "Area 1", "priority": "High"}},
    {{"name": "Area 2", "priority": "Medium"}},
    {{"name": "Area 3", "priority": "Low"}}
  ],

  "career_matches": [
    {{"rank": 1, "title": "Career A", "match": 94, "salary_range": "8-15 LPA", "growth": "High",   "years_to_senior": 4}},
    {{"rank": 2, "title": "Career B", "match": 88, "salary_range": "6-12 LPA", "growth": "High",   "years_to_senior": 5}},
    {{"rank": 3, "title": "Career C", "match": 81, "salary_range": "5-10 LPA", "growth": "Medium", "years_to_senior": 6}},
    {{"rank": 4, "title": "Career D", "match": 75, "salary_range": "4-8 LPA",  "growth": "Medium", "years_to_senior": 7}},
    {{"rank": 5, "title": "Career E", "match": 68, "salary_range": "3-7 LPA",  "growth": "Low",    "years_to_senior": 8}}
  ],

  "skills_gap": [
    {{"skill": "Skill 1", "current": 40, "required": 80}},
    {{"skill": "Skill 2", "current": 55, "required": 85}},
    {{"skill": "Skill 3", "current": 30, "required": 75}},
    {{"skill": "Skill 4", "current": 60, "required": 90}}
  ],

  "roadmap": [
    {{"phase": "0-6 Months",  "focus": "Short focus title", "action": "One clear action sentence.", "milestone": "Milestone text"}},
    {{"phase": "6-12 Months", "focus": "Short focus title", "action": "One clear action sentence.", "milestone": "Milestone text"}},
    {{"phase": "1-2 Years",   "focus": "Short focus title", "action": "One clear action sentence.", "milestone": "Milestone text"}},
    {{"phase": "2-3 Years",   "focus": "Short focus title", "action": "One clear action sentence.", "milestone": "Milestone text"}},
    {{"phase": "3-5 Years",   "focus": "Short focus title", "action": "One clear action sentence.", "milestone": "Milestone text"}}
  ],

  "education_paths": [
    {{"degree": "Degree/Course", "duration": "X years", "relevance": 90}},
    {{"degree": "Degree/Course", "duration": "X years", "relevance": 80}},
    {{"degree": "Degree/Course", "duration": "X years", "relevance": 70}}
  ],

  "work_style": {{
    "Prefer Remote":     65,
    "Team Oriented":     80,
    "Detail Focused":    75,
    "Innovation Driven": 85
  }},

  "summary_line": "One crisp sentence describing the student career outlook."
}}
"""

# ── Questions ──────────────────────────────────────────────────────────────
QUESTIONS = [
    {"id":"name","text":"What is your name?","type":"text","placeholder":"Enter your full name"},
    {"id":"q1","text":"Which subjects do you enjoy most?","type":"checkbox",
     "options":["Mathematics","Science","Literature","History","Computer Science","Arts / Design","Commerce","Physical Education"]},
    {"id":"q2","text":"How do you spend your free time?","type":"radio",
     "options":["Reading / Research","Building / Creating","Socialising / Helping","Sports / Fitness","Exploring Tech","Music / Art"]},
    {"id":"q3","text":"Which best describes your working style?","type":"radio",
     "options":["Work independently","Collaborative team","Mix of both","Leading others"]},
    {"id":"q4","text":"What type of problems excite you?","type":"radio",
     "options":["Logical / Math puzzles","Creative and design challenges","Human and social issues","Technical / Engineering problems","Business and financial problems","Scientific research"]},
    {"id":"q5","text":"Which are your strongest skills?","type":"checkbox",
     "options":["Analytical thinking","Public speaking","Creativity","Leadership","Coding / Technical","Empathy","Planning and organising","Writing"]},
    {"id":"q6","text":"How do you handle pressure?","type":"radio",
     "options":["Calm and systematic","Motivated under pressure","Stressful but manageable","Prefer low-pressure work"]},
    {"id":"q7","text":"What matters most in a career?","type":"radio",
     "options":["High salary","Positive social impact","Creative freedom","Job security","Cutting-edge work","Recognition"]},
    {"id":"q8","text":"Which industries interest you?","type":"checkbox",
     "options":["Technology / IT","Healthcare","Education / Research","Business / Finance","Creative Arts / Media","Engineering","Government / Public Service","Environment"]},
    {"id":"q9","text":"Ideal workplace type?","type":"radio",
     "options":["Innovative (startup/lab)","Structured (corporate/govt)","Flexible (freelance/remote)","Social (NGO/school/hospital)","Creative (studio/agency)","Outdoor / Field-based"]},
    {"id":"q10","text":"Comfort level with technology?","type":"radio",
     "options":["Very comfortable - I love coding","Comfortable with everyday tools","Neutral - use when needed","Prefer non-technical work"]},
    {"id":"q11","text":"Extracurricular activities?","type":"checkbox",
     "options":["Sports","Debate / Public speaking","Drama / Theatre","Science / Tech clubs","Community service","Music / Arts","Entrepreneurship clubs","None"]},
    {"id":"q12","text":"Biggest fear about your career?","type":"radio",
     "options":["Choosing wrong path","Not earning enough","Lack of job opportunities","Not being good enough","Monotony / boredom","Work-life imbalance"]},
    {"id":"q13","text":"Where do you see yourself in 5 years?","type":"radio",
     "options":["Running my own startup","Top company in my field","Higher studies / research","Making community impact","Still exploring","Stable career and family life"]}
]

# ── Colours ────────────────────────────────────────────────────────────────
NAVY   = colors.HexColor("#0d1b4b")
INDIGO = colors.HexColor("#2d3a8c")
TEAL   = colors.HexColor("#0e7490")
ACCENT = colors.HexColor("#f59e0b")
GREEN  = colors.HexColor("#16a34a")
RED    = colors.HexColor("#dc2626")
ORANGE = colors.HexColor("#ea580c")
LIGHT  = colors.HexColor("#f0f4ff")
LTGRAY = colors.HexColor("#f8f9fa")
GRAY   = colors.HexColor("#6b7280")
WHITE  = colors.white
BLACK  = colors.HexColor("#111827")

PW = A4[0] - 28*mm   # usable page width (14mm margins each side)

# ── Shared paragraph styles (built once) ──────────────────────────────────
def make_styles():
    return {
        "B":  ParagraphStyle("B",  fontName="Helvetica-Bold",    fontSize=9,   textColor=BLACK, leading=12),
        "N":  ParagraphStyle("N",  fontName="Helvetica",          fontSize=8.5, textColor=BLACK, leading=12),
        "SM": ParagraphStyle("SM", fontName="Helvetica",          fontSize=7.5, textColor=GRAY,  leading=11),
        "C":  ParagraphStyle("C",  fontName="Helvetica",          fontSize=8,   textColor=BLACK, leading=11, alignment=TA_CENTER),
        "CB": ParagraphStyle("CB", fontName="Helvetica-Bold",     fontSize=8,   textColor=BLACK, leading=11, alignment=TA_CENTER),
        "R":  ParagraphStyle("R",  fontName="Helvetica",          fontSize=8,   textColor=BLACK, leading=11, alignment=TA_RIGHT),
        "WHdr": ParagraphStyle("WHdr", fontName="Helvetica-Bold", fontSize=8,   textColor=WHITE, leading=11, alignment=TA_CENTER),
    }

def P(txt, s):
    safe = str(txt).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
    return Paragraph(safe, s)

def mini_bar(pct, width, fill=INDIGO, bg=colors.HexColor("#dde3ff"), h=7):
    filled = max(1, int(width * pct / 100))
    empty  = width - filled
    f = Table([[""]], colWidths=[filled], rowHeights=[h])
    f.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),fill),("GRID",(0,0),(-1,-1),0,WHITE)]))
    e = Table([[""]], colWidths=[empty],  rowHeights=[h])
    e.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),bg), ("GRID",(0,0),(-1,-1),0,WHITE)]))
    outer = Table([[f, e]], colWidths=[filled, empty], rowHeights=[h])
    outer.setStyle(TableStyle([
        ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
        ("TOPPADDING",(0,0),(-1,-1),0),("BOTTOMPADDING",(0,0),(-1,-1),0),
    ]))
    return outer

def badge(text, bg, fg=WHITE, w=40):
    s = ParagraphStyle("Bdg", fontName="Helvetica-Bold", fontSize=7.5, textColor=fg, alignment=TA_CENTER)
    t = Table([[P(text, s)]], colWidths=[w])
    t.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1),bg),
        ("TOPPADDING",(0,0),(-1,-1),2),("BOTTOMPADDING",(0,0),(-1,-1),2),
        ("LEFTPADDING",(0,0),(-1,-1),3),("RIGHTPADDING",(0,0),(-1,-1),3),
    ]))
    return t

def growth_badge(g):
    c = {"High": GREEN, "Medium": ORANGE, "Low": RED}.get(g, GRAY)
    return badge(g, c, w=42)

def priority_badge(p):
    c = {"High": RED, "Medium": ORANGE, "Low": GREEN}.get(p, GRAY)
    return badge(p, c, w=38)

def section_header(title):
    s = ParagraphStyle("SH", fontName="Helvetica-Bold", fontSize=9, textColor=WHITE, leading=12)
    t = Table([[P(f"  {title}", s)]], colWidths=[PW])
    t.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1),NAVY),
        ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5),
        ("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),6),
    ]))
    return [t, Spacer(1,5)]

COMMON_STYLE = [
    ("TOPPADDING",(0,0),(-1,-1),4),("BOTTOMPADDING",(0,0),(-1,-1),4),
    ("LEFTPADDING",(0,0),(-1,-1),5),("RIGHTPADDING",(0,0),(-1,-1),5),
    ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
    ("GRID",(0,0),(-1,-1),0.3,colors.HexColor("#d1d5db")),
]

# ── PDF Generator ──────────────────────────────────────────────────────────
def generate_pdf(report):
    buf = io.BytesIO()
    S = make_styles()

    def page_deco(canv, doc):
        canv.saveState()
        canv.setFillColor(NAVY)
        canv.rect(14*mm, A4[1]-10*mm, A4[0]-28*mm, 2.5, fill=1, stroke=0)
        canv.setFillColor(NAVY)
        canv.rect(14*mm, 7*mm, A4[0]-28*mm, 1, fill=1, stroke=0)
        canv.setFont("Helvetica", 7)
        canv.setFillColor(GRAY)
        canv.drawString(14*mm, 4.5*mm, "AI Career Counseling System  |  For guidance purposes only")
        canv.drawRightString(A4[0]-14*mm, 4.5*mm,
            f"Generated: {datetime.date.today().strftime('%d %b %Y')}  |  Page {doc.page}")
        canv.restoreState()

    doc = SimpleDocTemplate(buf, pagesize=A4,
        topMargin=14*mm, bottomMargin=15*mm,
        leftMargin=14*mm, rightMargin=14*mm,
        onFirstPage=page_deco, onLaterPages=page_deco)

    E = []

    # ── HEADER ────────────────────────────────────────────────────────────
    name    = report.get("student_name","Student")
    ptype   = report.get("personality_type","—")
    mbti    = report.get("mbti_code","—")
    ofs     = report.get("overall_fit_score", 0)
    sumline = report.get("summary_line","")
    ageGrp  = report.get("age_group","—")

    ofs_pct = min(int(ofs), 100)
    ofs_color = GREEN if ofs_pct >= 80 else (ORANGE if ofs_pct >= 60 else RED)

    T1 = ParagraphStyle("T1", fontName="Helvetica-Bold", fontSize=10, textColor=TEAL, leading=13)
    T2 = ParagraphStyle("T2", fontName="Helvetica-Bold", fontSize=20, textColor=NAVY, leading=24)
    T3 = ParagraphStyle("T3", fontName="Helvetica",       fontSize=9,  textColor=GRAY, leading=12)
    T4 = ParagraphStyle("T4", fontName="Helvetica-Oblique", fontSize=9, textColor=INDIGO, leading=13)
    SC = ParagraphStyle("SC", fontName="Helvetica-Bold", fontSize=26, textColor=ofs_color, alignment=TA_CENTER, leading=30)
    SL = ParagraphStyle("SL", fontName="Helvetica",       fontSize=7,  textColor=GRAY,  alignment=TA_CENTER)

    score_inner = [
        [P(str(ofs), SC)],
        [P("FIT SCORE", SL)],
        [P("out of 100", SL)],
    ]
    score_tbl = Table(score_inner, colWidths=[58])
    score_tbl.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1),LIGHT),
        ("BOX",(0,0),(-1,-1),1,INDIGO),
        ("TOPPADDING",(0,0),(-1,-1),6),("BOTTOMPADDING",(0,0),(-1,-1),6),
        ("LEFTPADDING",(0,0),(-1,-1),4),("RIGHTPADDING",(0,0),(-1,-1),4),
    ]))

    left_content = [
        P("CAREER COUNSELING REPORT", T1), Spacer(1,3),
        P(name, T2), Spacer(1,4),
        P(f"Personality: {ptype}  ({mbti})   |   Age Group: {ageGrp}", T3), Spacer(1,4),
        P(sumline, T4),
    ]
    hdr = Table([[left_content, score_tbl]], colWidths=[PW-68, 68])
    hdr.setStyle(TableStyle([
        ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
        ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
        ("TOPPADDING",(0,0),(-1,-1),0),("BOTTOMPADDING",(0,0),(-1,-1),0),
    ]))
    E.append(hdr)
    E.append(Spacer(1,5))
    E.append(HRFlowable(width=PW, thickness=1.5, color=ACCENT))
    E.append(Spacer(1,8))

    # ── SECTION 01: TRAIT SCORES + STRENGTHS ──────────────────────────────
    E += section_header("01   TRAIT SCORES  &  TOP STRENGTHS")

    trait_scores = report.get("trait_scores", {})
    strengths    = report.get("top_strengths", [])

    # Trait bars (left side)
    t_rows = []
    for trait, score in trait_scores.items():
        fill = GREEN if score >= 75 else (ORANGE if score >= 50 else RED)
        t_rows.append([
            P(trait, S["N"]),
            mini_bar(score, width=70, fill=fill),
            P(f"{score}%", S["R"]),
        ])
    trait_tbl = Table(t_rows, colWidths=[62, 72, 22])
    trait_tbl.setStyle(TableStyle(COMMON_STYLE + [
        ("ROWBACKGROUNDS",(0,0),(-1,-1),[LTGRAY, WHITE]),
    ]))

    # Strengths table (right side)
    str_hdr  = [P("STRENGTH", S["WHdr"]), P("SCORE", S["WHdr"])]
    str_rows = [str_hdr]
    for st in strengths:
        sc = st.get("score", 0)
        str_rows.append([
            P(st.get("name",""), S["N"]),
            P(f"{sc}%", ParagraphStyle("GS", fontName="Helvetica-Bold", fontSize=8,
                textColor=GREEN if sc>=75 else ORANGE, alignment=TA_CENTER)),
        ])
    str_tbl = Table(str_rows, colWidths=[92, 30])
    str_tbl.setStyle(TableStyle(COMMON_STYLE + [
        ("BACKGROUND",(0,0),(-1,0), NAVY),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[LTGRAY, WHITE]),
    ]))

    E.append(Table([[trait_tbl, str_tbl]], colWidths=[160, 124]))
    E[-1].setStyle(TableStyle([
        ("VALIGN",(0,0),(-1,-1),"TOP"),
        ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
        ("TOPPADDING",(0,0),(-1,-1),0),("BOTTOMPADDING",(0,0),(-1,-1),0),
    ]))
    E.append(Spacer(1,9))

    # ── SECTION 02: CAREER MATCHES ─────────────────────────────────────────
    E += section_header("02   CAREER MATCH ANALYSIS")

    careers = report.get("career_matches", [])
    car_hdr = [P(h, S["WHdr"]) for h in ["#","CAREER TITLE","MATCH %","MATCH BAR","SALARY RANGE","GROWTH","YRS TO SENIOR"]]
    car_rows = [car_hdr]
    for c in careers:
        pct = c.get("match", 0)
        fc  = GREEN if pct >= 85 else (INDIGO if pct >= 75 else ORANGE)
        car_rows.append([
            P(f"#{c.get('rank','-')}", S["CB"]),
            P(c.get("title",""), S["B"]),
            P(f"{pct}%", ParagraphStyle("MP", fontName="Helvetica-Bold", fontSize=9,
                textColor=fc, alignment=TA_CENTER)),
            mini_bar(pct, width=55, fill=fc),
            P(c.get("salary_range",""), S["C"]),
            growth_badge(c.get("growth","Medium")),
            P(str(c.get("years_to_senior","—")), S["C"]),
        ])
    car_tbl = Table(car_rows, colWidths=[22, 94, 32, 57, 52, 46, 46])
    car_tbl.setStyle(TableStyle(COMMON_STYLE + [
        ("BACKGROUND",(0,0),(-1,0), NAVY),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[LTGRAY, WHITE]),
    ]))
    E.append(car_tbl)
    E.append(Spacer(1,9))

    # ── SECTION 03: SKILLS GAP + IMPROVEMENT AREAS ────────────────────────
    E += section_header("03   SKILLS GAP ANALYSIS  &  IMPROVEMENT AREAS")

    skills_gap = report.get("skills_gap", [])
    improv     = report.get("improvement_areas", [])

    sg_hdr  = [P(h, S["WHdr"]) for h in ["SKILL","CURRENT","GAP BAR","REQUIRED","GAP"]]
    sg_rows = [sg_hdr]
    for sk in skills_gap:
        cur = sk.get("current", 0)
        req = sk.get("required", 0)
        gap = req - cur
        sg_rows.append([
            P(sk.get("skill",""), S["N"]),
            P(f"{cur}%", S["C"]),
            mini_bar(cur, width=55, fill=INDIGO, bg=colors.HexColor("#fca5a5")),
            P(f"{req}%", S["C"]),
            P(f"-{gap}%", ParagraphStyle("GP", fontName="Helvetica-Bold", fontSize=8,
                textColor=RED, alignment=TA_CENTER)),
        ])
    sg_tbl = Table(sg_rows, colWidths=[68, 30, 57, 30, 30])
    sg_tbl.setStyle(TableStyle(COMMON_STYLE + [
        ("BACKGROUND",(0,0),(-1,0), TEAL),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[LTGRAY, WHITE]),
    ]))

    im_hdr  = [P("AREA TO IMPROVE", S["WHdr"]), P("PRIORITY", S["WHdr"])]
    im_rows = [im_hdr]
    for a in improv:
        im_rows.append([
            P(a.get("name",""), S["N"]),
            priority_badge(a.get("priority","Medium")),
        ])
    im_tbl = Table(im_rows, colWidths=[92, 42])
    im_tbl.setStyle(TableStyle(COMMON_STYLE + [
        ("BACKGROUND",(0,0),(-1,0), TEAL),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[LTGRAY, WHITE]),
    ]))

    E.append(Table([[sg_tbl, im_tbl]], colWidths=[219, 134]))
    E[-1].setStyle(TableStyle([
        ("VALIGN",(0,0),(-1,-1),"TOP"),
        ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
        ("TOPPADDING",(0,0),(-1,-1),0),("BOTTOMPADDING",(0,0),(-1,-1),0),
    ]))
    E.append(Spacer(1,9))

    # ── SECTION 04: ROADMAP ───────────────────────────────────────────────
    E += section_header("04   5-PHASE CAREER ROADMAP")

    roadmap = report.get("roadmap", [])
    rm_hdr  = [P(h, S["WHdr"]) for h in ["PHASE","FOCUS AREA","KEY ACTION","MILESTONE"]]
    rm_rows = [rm_hdr]
    phase_bg = [
        colors.HexColor("#1e3a8a"),
        colors.HexColor("#1d4ed8"),
        colors.HexColor("#2563eb"),
        colors.HexColor("#3b82f6"),
        colors.HexColor("#93c5fd"),
    ]
    phase_fg = [WHITE, WHITE, WHITE, WHITE, NAVY]
    for i, r in enumerate(roadmap):
        ph_s = ParagraphStyle("PH", fontName="Helvetica-Bold", fontSize=8,
                               textColor=phase_fg[min(i,4)], alignment=TA_CENTER)
        rm_rows.append([
            P(r.get("phase",""), ph_s),
            P(r.get("focus",""), S["B"]),
            P(r.get("action",""), S["N"]),
            P(r.get("milestone",""), S["SM"]),
        ])
    rm_tbl = Table(rm_rows, colWidths=[54, 60, 120, 85])
    rm_style = list(COMMON_STYLE) + [("BACKGROUND",(0,0),(-1,0), NAVY)]
    for i in range(len(roadmap)):
        rm_style.append(("BACKGROUND",(0,i+1),(0,i+1), phase_bg[min(i,4)]))
        rm_style.append(("BACKGROUND",(1,i+1),(-1,i+1), LTGRAY if i%2==0 else WHITE))
    rm_tbl.setStyle(TableStyle(rm_style))
    E.append(rm_tbl)
    E.append(Spacer(1,9))

    # ── SECTION 05: EDUCATION + WORK STYLE ───────────────────────────────
    E += section_header("05   EDUCATION PATHWAYS  &  WORK STYLE PROFILE")

    edu    = report.get("education_paths", [])
    wstyle = report.get("work_style", {})

    edu_hdr  = [P(h, S["WHdr"]) for h in ["DEGREE / COURSE","DURATION","RELEVANCE","BAR"]]
    edu_rows = [edu_hdr]
    for e in edu:
        rel = e.get("relevance", 0)
        edu_rows.append([
            P(e.get("degree",""), S["N"]),
            P(e.get("duration",""), S["C"]),
            P(f"{rel}%", ParagraphStyle("ER", fontName="Helvetica-Bold", fontSize=8,
                textColor=GREEN, alignment=TA_CENTER)),
            mini_bar(rel, width=42, fill=GREEN, bg=colors.HexColor("#dcfce7")),
        ])
    edu_tbl = Table(edu_rows, colWidths=[94, 32, 32, 44])
    edu_tbl.setStyle(TableStyle(COMMON_STYLE + [
        ("BACKGROUND",(0,0),(-1,0), INDIGO),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[LTGRAY, WHITE]),
    ]))

    ws_rows = []
    for trait, score in wstyle.items():
        ws_rows.append([
            P(trait, S["N"]),
            mini_bar(score, width=55, fill=TEAL, bg=colors.HexColor("#cffafe")),
            P(f"{score}%", S["R"]),
        ])
    ws_tbl = Table(ws_rows, colWidths=[80, 57, 24])
    ws_tbl.setStyle(TableStyle([
        ("ROWBACKGROUNDS",(0,0),(-1,-1),[LTGRAY, WHITE]),
        ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5),
        ("LEFTPADDING",(0,0),(-1,-1),6),("RIGHTPADDING",(0,0),(-1,-1),4),
        ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
        ("BOX",(0,0),(-1,-1),0.3,colors.HexColor("#d1d5db")),
    ]))

    E.append(Table([[edu_tbl, ws_tbl]], colWidths=[206, 147]))
    E[-1].setStyle(TableStyle([
        ("VALIGN",(0,0),(-1,-1),"TOP"),
        ("LEFTPADDING",(0,0),(-1,-1),0),("RIGHTPADDING",(0,0),(-1,-1),0),
        ("TOPPADDING",(0,0),(-1,-1),0),("BOTTOMPADDING",(0,0),(-1,-1),0),
    ]))
    E.append(Spacer(1,9))

    # ── LEGEND ────────────────────────────────────────────────────────────
    leg_s = ParagraphStyle("LS", fontName="Helvetica", fontSize=7.5, textColor=GRAY, alignment=TA_CENTER)
    leg = Table([[
        P("90-100  Excellent Fit", leg_s),
        P("75-89   Strong Fit",    leg_s),
        P("60-74   Moderate Fit",  leg_s),
        P("< 60    Explore More",  leg_s),
    ]], colWidths=[PW/4]*4)
    leg.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,-1), LIGHT),
        ("BOX",(0,0),(-1,-1),0.5,INDIGO),
        ("TOPPADDING",(0,0),(-1,-1),5),("BOTTOMPADDING",(0,0),(-1,-1),5),
        ("LEFTPADDING",(0,0),(-1,-1),4),("RIGHTPADDING",(0,0),(-1,-1),4),
    ]))
    E.append(leg)

    doc.build(E)
    buf.seek(0)
    return buf


# ── HTML UI ────────────────────────────────────────────────────────────────
HTML_PAGE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AI Career Counselor</title>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Public+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{--primary:#ff5f00;--secondary:#002479;--cream:#eae2b7;--text:#1f2937;--muted:#64748b;}
*{margin:0;padding:0;box-sizing:border-box;}
body{
  font-family:'Public Sans',sans-serif;
  background:
    radial-gradient(circle at 12% 12%, rgba(255,95,0,.13), transparent 45%),
    radial-gradient(circle at 88% 88%, rgba(0,36,121,.10), transparent 42%),
    linear-gradient(165deg,#fffdf7 0%,#fff6e7 100%);
  min-height:100vh;display:flex;flex-direction:column;align-items:center;padding:38px 16px;
}
header{text-align:center;margin-bottom:28px;}
header h1{font-family:'Outfit',sans-serif;font-size:2rem;color:var(--secondary);letter-spacing:-.02em;}
header p{color:var(--muted);font-size:.96rem;margin-top:6px;}
.card{background:#fff;border-radius:20px;width:100%;max-width:700px;box-shadow:0 16px 52px rgba(0,0,0,.11);border:1px solid rgba(0,36,121,.10);overflow:hidden;}
.prog-wrap{height:5px;background:#e7edf9;}
.prog-bar{height:5px;background:linear-gradient(90deg,var(--secondary),var(--primary));transition:width .35s;}
.q-area{padding:30px 34px 8px;}
.q-label{font-size:.72rem;font-weight:600;text-transform:uppercase;letter-spacing:.1em;color:#64748b;margin-bottom:6px;}
.q-text{font-size:1.1rem;font-family:'Outfit',sans-serif;font-weight:600;color:var(--secondary);margin-bottom:16px;line-height:1.45;}
input[type=text]{width:100%;padding:11px 14px;border:1.7px solid #dbe3f2;border-radius:12px;font-size:.96rem;color:#111;outline:none;font-family:inherit;transition:border .2s,box-shadow .2s;}
input[type=text]:focus{border-color:var(--secondary);box-shadow:0 0 0 3px rgba(0,36,121,.12);}
.opts{display:flex;flex-direction:column;gap:8px;}
.opt{display:flex;align-items:center;gap:11px;padding:10px 14px;border:1.7px solid #dbe3f2;border-radius:12px;cursor:pointer;transition:all .16s;font-size:.93rem;color:var(--text);}
.opt:hover{border-color:var(--secondary);background:#f8fbff;}
.opt.selected{border-color:var(--primary);background:#fff7ed;}
.opt input{accent-color:var(--secondary);width:16px;height:16px;cursor:pointer;flex-shrink:0;}
.nav{display:flex;justify-content:space-between;align-items:center;padding:18px 34px 24px;}
.nav button{padding:10px 24px;border:none;border-radius:999px;font-size:.93rem;font-weight:700;cursor:pointer;font-family:'Outfit',sans-serif;transition:all .16s;}
#prevBtn{background:#eef3ff;color:var(--secondary);}#prevBtn:hover{background:#dfe9ff;}
#nextBtn{background:var(--primary);color:#fff;min-width:138px;}#nextBtn:hover{filter:brightness(.96);transform:translateY(-1px);}
#nextBtn:disabled{opacity:.6;cursor:wait;transform:none;}
.counter{color:#64748b;font-size:.82rem;}
.result-area{padding:34px;text-align:center;display:none;}
.result-area h2{font-family:'Outfit',sans-serif;color:var(--secondary);font-size:1.45rem;margin-bottom:8px;}
.result-area p{color:#4b5563;font-size:.93rem;margin-bottom:20px;}
.dl-btn{display:inline-block;padding:12px 32px;background:var(--primary);color:#fff;border-radius:999px;font-size:.97rem;font-weight:700;cursor:pointer;border:none;font-family:'Outfit',sans-serif;}
.dl-btn:hover{filter:brightness(.96);}
.restart{margin-top:12px;background:none;border:none;color:#64748b;cursor:pointer;font-size:.88rem;font-family:inherit;text-decoration:underline;display:block;margin-left:auto;margin-right:auto;}
.spinner{display:none;margin:24px auto 8px;width:40px;height:40px;border:4px solid #e2e8f0;border-top-color:var(--primary);border-radius:50%;animation:spin 1s linear infinite;}
@keyframes spin{to{transform:rotate(360deg);}}
.err{color:#dc2626;font-size:.88rem;margin-top:8px;}
</style>
</head>
<body>
<header>
  <h1>AI Career Counselor</h1>
  <p>Answer 14 questions — get a data-driven statistical career report PDF</p>
</header>
<div class="card">
  <div class="prog-wrap"><div class="prog-bar" id="bar"></div></div>
  <div class="q-area" id="qArea"></div>
  <div class="nav">
    <button id="prevBtn" onclick="prev()">Back</button>
    <span class="counter" id="counter"></span>
    <button id="nextBtn" onclick="next()">Next</button>
  </div>
  <div class="result-area" id="resultArea">
    <div class="spinner" id="spinner"></div>
    <h2 id="resTitle"></h2>
    <p id="resMsg"></p>
    <button class="dl-btn" id="dlBtn" style="display:none">Download PDF Report</button>
    <div class="err" id="errMsg"></div>
    <button class="restart" onclick="restart()">Start over</button>
  </div>
</div>
<script>
const QUESTIONS = """ + json.dumps(QUESTIONS) + r""";
let current = 0;
const answers = {};
function renderQ(){
  const q=QUESTIONS[current];
  document.getElementById('bar').style.width=(current/QUESTIONS.length*100)+'%';
  document.getElementById('counter').textContent=`${current+1} / ${QUESTIONS.length}`;
  document.getElementById('nextBtn').textContent=current===QUESTIONS.length-1?'Generate Report':'Next';
  let html=`<div class="q-label">Question ${current+1} of ${QUESTIONS.length}</div>`;
  html+=`<div class="q-text">${q.text}</div>`;
  if(q.type==='text'){
    html+=`<input type="text" id="inp" placeholder="${q.placeholder||''}" value="${answers[q.id]||''}" onkeydown="if(event.key==='Enter')next()">`;
  }else if(q.type==='radio'){
    html+='<div class="opts">';
    q.options.forEach(o=>{
      const sel=answers[q.id]===o?'selected':'';
      html+=`<label class="opt ${sel}"><input type="radio" name="rq" value="${o}" ${sel?'checked':''} onchange="pickR(this,'${q.id}')"> ${o}</label>`;
    });
    html+='</div>';
  }else{
    const prev=answers[q.id]||[];
    html+='<div class="opts">';
    q.options.forEach(o=>{
      const sel=prev.includes(o)?'selected':'';
      html+=`<label class="opt ${sel}"><input type="checkbox" value="${o}" ${sel?'checked':''} onchange="pickC(this,'${q.id}')"> ${o}</label>`;
    });
    html+='</div>';
  }
  document.getElementById('qArea').innerHTML=html;
  document.getElementById('prevBtn').style.visibility=current===0?'hidden':'visible';
  if(q.type==='text')document.getElementById('inp').focus();
}
function pickR(el,id){
  answers[id]=el.value;
  document.querySelectorAll('.opt').forEach(o=>o.classList.remove('selected'));
  el.closest('.opt').classList.add('selected');
}
function pickC(el,id){
  if(!answers[id])answers[id]=[];
  if(el.checked){if(!answers[id].includes(el.value))answers[id].push(el.value);}
  else answers[id]=answers[id].filter(v=>v!==el.value);
  el.closest('.opt').classList.toggle('selected',el.checked);
}
function getA(){
  const q=QUESTIONS[current];
  if(q.type==='text'){const v=document.getElementById('inp')?.value.trim();if(v)answers[q.id]=v;}
}
function next(){
  getA();
  const q=QUESTIONS[current];
  if(!answers[q.id]||(Array.isArray(answers[q.id])&&answers[q.id].length===0)){alert('Please answer this question.');return;}
  if(current<QUESTIONS.length-1){current++;renderQ();}else{submit();}
}
function prev(){getA();if(current>0){current--;renderQ();}}
function submit(){
  document.querySelector('.nav').style.display='none';
  document.getElementById('qArea').style.display='none';
  document.getElementById('resultArea').style.display='block';
  document.getElementById('spinner').style.display='block';
  document.getElementById('resTitle').textContent='Analysing your profile...';
  document.getElementById('resMsg').textContent='Generating your statistical career report. This takes 15-30 seconds.';
  fetch('/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(answers)})
  .then(async res=>{
    document.getElementById('spinner').style.display='none';
    if(!res.ok){const e=await res.json();throw new Error(e.error||'Failed');}
    const blob=await res.blob();
    const url=URL.createObjectURL(blob);
    document.getElementById('resTitle').textContent='Report Ready!';
    document.getElementById('resMsg').textContent='Your statistical career counseling report has been generated.';
    const btn=document.getElementById('dlBtn');
    btn.style.display='inline-block';
    btn.onclick=()=>{const a=document.createElement('a');a.href=url;a.download='career_report.pdf';a.click();};
  }).catch(err=>{
    document.getElementById('spinner').style.display='none';
    document.getElementById('resTitle').textContent='Something went wrong';
    document.getElementById('errMsg').textContent='Error: '+err.message;
  });
}
function restart(){
  current=0;Object.keys(answers).forEach(k=>delete answers[k]);
  document.querySelector('.nav').style.display='flex';
  document.getElementById('qArea').style.display='block';
  document.getElementById('resultArea').style.display='none';
  renderQ();
}
renderQ();
</script>
</body>
</html>"""


# ── Routes ─────────────────────────────────────────────────────────────────
@app.route("/")
def home():
    return HTML_PAGE

@app.route("/generate", methods=["POST"])
def generate():
    data = request.json or {}
    if not data:
        return jsonify({"error": "No data received"}), 400
    q_map = {q["id"]: q["text"] for q in QUESTIONS}
    lines = []
    for qid, answer in data.items():
        qt  = q_map.get(qid, qid)
        ans = ", ".join(answer) if isinstance(answer, list) else str(answer)
        lines.append(f"Q: {qt}\nA: {ans}")
    prompt = PROMPT_TEMPLATE.format(responses="\n\n".join(lines))
    try:
        ai_resp = model.generate_content(prompt)
        text = ai_resp.text.strip()
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
        report = json.loads(text)
    except Exception as e:
        return jsonify({"error": f"AI error: {str(e)}"}), 500
    try:
        pdf_buf = generate_pdf(report)
    except Exception as e:
        return jsonify({"error": f"PDF error: {str(e)}"}), 500
    return send_file(pdf_buf, mimetype="application/pdf",
                     as_attachment=True, download_name="career_report.pdf")


# ── Entry ───────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    def start_ngrok():
        time.sleep(2)
        try:
            from pyngrok import ngrok
            t = ngrok.connect(5000)
            print(f"\n{'='*55}\n  NGROK URL: {t.public_url}\n{'='*55}\n")
        except Exception:
            print("\nRunning at http://localhost:5000\n")
    threading.Thread(target=start_ngrok, daemon=True).start()
    print("\n" + "="*55)
    print("  AI Career Counseling System")
    print("  Open: http://localhost:5000")
    print("="*55 + "\n")
    app.run(host="0.0.0.0", port=5002, debug=False)
